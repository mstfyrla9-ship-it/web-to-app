package com.webtoapp.core.agent.llm

import android.content.Context
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.webtoapp.core.network.NetworkModule
import com.webtoapp.data.model.AiProvider
import com.webtoapp.data.model.ApiFormat
import com.webtoapp.util.GsonProvider
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.UUID

internal class GeminiProvider(@Suppress("UNUSED_PARAMETER") context: Context) : LlmProvider {
    private val gson = GsonProvider.gson; private val sse = SseParser(); private val client get() = NetworkModule.streamingClient
    override fun supports(provider: AiProvider) = provider == AiProvider.GOOGLE
    override fun supports(req: ChatRequest): Boolean =
        req.apiKey.provider == AiProvider.GOOGLE ||
            (req.apiKey.provider == AiProvider.CUSTOM &&
                req.apiKey.apiFormat == ApiFormat.GOOGLE_GEMINI)
    override fun chatStream(req: ChatRequest): Flow<LlmEvent> = callbackFlow {
        val base = HttpHelpers.baseUrl(req.apiKey); val key = req.apiKey.apiKey.trim()
        val customGemini = req.apiKey.provider == AiProvider.CUSTOM &&
            req.apiKey.apiFormat == ApiFormat.GOOGLE_GEMINI
        val endpoint = req.apiKey.getEffectiveChatEndpoint()
        val url = if (customGemini) {
            val resolved = endpoint
                .replace("{model}", req.model.id)
                .replace(":model", req.model.id)
            val joined = HttpHelpers.joinUrl(base, resolved)
            if (joined.contains("?")) "$joined&alt=sse&key=$key"
            else "$joined?alt=sse&key=$key"
        } else {
            "$base/v1beta/models/${req.model.id}:streamGenerateContent?alt=sse&key=$key"
        }
        val body = buildBody(req)
        val requestBuilder = Request.Builder()
            .url(url)
            .header("Content-Type","application/json")
        if (customGemini) requestBuilder.header("x-goog-api-key", key)
        val request = requestBuilder
            .post(gson.toJson(body).toRequestBody("application/json".toMediaType()))
            .build()
        trySend(LlmEvent.Started)
        val call = client.newCall(request)
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                trySend(HttpHelpers.networkError(e, url)); close()
            }
            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) { val eb=runCatching{response.body?.string()}.getOrNull().orEmpty(); val ra=response.header("Retry-After"); val ram=response.header("retry-after-ms"); response.body?.close(); trySend(HttpHelpers.llmHttpError(response.code, eb, ra, ram)); close(); return }
                try {
                    val source = response.body?.source() ?: run { trySend(LlmEvent.Error("Empty response body")); close(); return }
                    var hasTools = false
                    var lastToolId: String? = null
                    sse.consume(source) { _, payload ->
                        try {
                            val json = JsonParser.parseString(payload).asJsonObject
                            val cand = json.getAsJsonArray("candidates")?.takeIf{it.size()>0}?.get(0)?.asJsonObject ?: return@consume true
                            cand.getAsJsonObject("content")?.getAsJsonArray("parts")?.forEach { pEl ->
                                val p = pEl.asJsonObject
                                p.get("text")?.takeUnless{it.isJsonNull}?.asString?.takeIf{it.isNotEmpty()}?.let{trySend(LlmEvent.TextDelta(it))}
                                val fc = p.getAsJsonObject("functionCall")
                                if (fc != null) {
                                    hasTools = true
                                    val nm = fc.get("name")?.asString.orEmpty()
                                    val args = fc.get("args")?.let { gson.toJson(it) }.orEmpty()
                                    val id = "gem_${UUID.randomUUID()}"
                                    lastToolId = id
                                    val sig = ThoughtSignatures.fromGeminiPart(p, fc)
                                    trySend(LlmEvent.ToolCallBegin(id, nm))
                                    if (args.isNotEmpty()) trySend(LlmEvent.ToolCallArgsDelta(id, args))
                                    trySend(LlmEvent.ToolCallEnd(id, nm, args, sig))
                                } else {
                                    val sig = ThoughtSignatures.fromGeminiPart(p, JsonObject())
                                    val id = lastToolId
                                    if (sig != null && id != null) {
                                        trySend(LlmEvent.ToolCallEnd(id, "", "", sig))
                                    }
                                }
                            }
                        } catch(_:Exception){}; true
                    }
                    trySend(LlmEvent.Done(if(hasTools) FinishReason.TOOL_CALLS else FinishReason.STOP))
                } catch (e: Exception) {
                    com.webtoapp.core.logging.AppLogger.w("GeminiProvider", "stream interrupted: ${e.message}")
                    trySend(LlmEvent.Error("Stream interrupted: ${e.message}", recoverable = true))
                } finally { runCatching{response.body?.close()}; close() }
            }
        }); awaitClose { call.cancel() }
    }
    private fun buildBody(req: ChatRequest): JsonObject {
        val sys = req.messages.filter{it.role==LlmMessage.Role.SYSTEM}.joinToString("\n\n"){it.content}
        val contents = JsonArray(); req.messages.filter{it.role!=LlmMessage.Role.SYSTEM}.forEach { m ->
            contents.add(JsonObject().apply { addProperty("role",if(m.role==LlmMessage.Role.ASSISTANT)"model" else "user"); add("parts",buildParts(m)) })
        }
        return JsonObject().apply {
            add("contents",contents)
            if(sys.isNotBlank()) add("systemInstruction",JsonObject().apply{add("parts",JsonArray().apply{add(JsonObject().apply{addProperty("text",sys)})})})
            add("generationConfig",JsonObject().apply{addProperty("temperature",req.temperature);req.maxTokens?.let{addProperty("maxOutputTokens",it)}})
            if(req.useTools&&req.tools.isNotEmpty()) add("tools",JsonArray().apply{add(JsonObject().apply{add("functionDeclarations",JsonArray().apply{req.tools.forEach{t->add(JsonObject().apply{addProperty("name",t.name);addProperty("description",t.description);add("parameters",t.parametersSchema)})}})})})
        }
    }
    private fun buildParts(m: LlmMessage): JsonArray { val parts=JsonArray()
        when(m.role){LlmMessage.Role.USER->{if(m.content.isNotEmpty())parts.add(JsonObject().apply{addProperty("text",m.content)})}
        LlmMessage.Role.ASSISTANT->{if(m.content.isNotEmpty())parts.add(JsonObject().apply{addProperty("text",m.content)});m.toolCalls.forEach{tc->parts.add(ThoughtSignatures.geminiPart(tc.name, tc.argumentsJson, tc.thoughtSignature))}}
        LlmMessage.Role.TOOL->{parts.add(JsonObject().apply{add("functionResponse",JsonObject().apply{addProperty("name",m.name?:"tool");add("response",JsonObject().apply{addProperty("result",m.content)})})})}
        else->{}}
        m.images.forEach { img -> parts.add(JsonObject().apply { add("inlineData", JsonObject().apply { addProperty("mimeType", img.mimeType); addProperty("data", base64(img.bytes)) }) }) }
        return parts
    }
    private fun base64(bytes: ByteArray) = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
}
